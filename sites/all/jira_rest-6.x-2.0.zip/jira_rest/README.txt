
CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Installation
 * Usage examples


INTRODUCTION
------------

Providing methods for creating, editing, searching JIRA issues out of Drupal via REST.

Features:
- search
- create
- modify
- close JIRA-issues

Requirements:
Extension for curl/libcurl must be enabled (http://www.php.net/curl).



INSTALLATION
------------

- make sure you have libcurl extension installed
- setup your jira-url for D6 at  ../admin/settings/jira_rest





USAGE EXAMPLES
-------------

TODO, as a start, see examples in comments in .module file
